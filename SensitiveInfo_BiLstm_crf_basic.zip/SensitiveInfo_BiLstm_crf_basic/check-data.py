#!/usr/bin/env python
# coding: utf-8

#cd drive/MyDrive/
import re
import os

def checkdata(fname:str):
    row = 0
    tokens_li, tags_li = [], []
    with open(fname, mode='r', encoding="utf-8") as f:
        sent_token_li, sent_tag_li = [], []
        for num,line in enumerate(f.readlines()):            
            line = line.strip()
            if (len(line) == 0):
                if len(sent_token_li) == 0: continue
                tokens_li.append(sent_token_li)
                tags_li.append(sent_tag_li)
                sent_token_li, sent_tag_li = [], []
            else:
                try:
                    if len(line.split()) < 2:
                        print(fname,num)
                    sent_token_li.append(line.split()[0])
                    sent_tag_li.append(line.split()[1])
                except Exception:
                    print("ill formatted line: " + line)
    
    print("Total of sentences: ", len(tokens_li), end="\t")
    num_entity = 0
    for sent_tag_li in tags_li:
        for tag in sent_tag_li:
            if tag.startswith("B"):
                num_entity += 1 
    print("Total of entities: ", num_entity)
        
if __name__=="__main__":
    checkdata('./data/train.txt')
    checkdata('./data/dev.txt')
    checkdata('./data/test.txt')