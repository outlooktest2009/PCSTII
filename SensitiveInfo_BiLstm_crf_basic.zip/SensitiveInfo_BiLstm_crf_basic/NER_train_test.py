# -*- coding: utf-8 -*-
'''
@Author: 
@Date: 
@LastEditTime: 
@Description:  
@All Right Reserve
'''

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils import data
import os
import argparse
from sklearn import metrics
from models import BiLSTM_CRF
from utils import NerDataset, PadBatch, get_accuracy_simple, get_prf1_entity, seq2entity
from config import Config, tag2idx, idx2tag, word2idx, idx2word
from NER import getEntities

os.environ['CUDA_VISIBLE_DEVICES'] = '0'

def train(e, model, iterator, optimizer, device):
    model.train()
    losses = 0.0
    step = 0
    for i, batch in enumerate(iterator):
        step += 1
        x, y, z = batch
        x = x.to(device)
        y = y.to(device)
        z = z.to(device)

        loss = model.loss(x, y, z)
        losses += loss.item()

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

    print("Epoch: {}, Loss:{:.4f}".format(e, losses/step))

def validate(e, model, iterator, device):
    model.eval()
    Y_true, Y_predict = [], []
    losses = 0
    step = 0
    with torch.no_grad():
        for i, batch in enumerate(iterator):
            step += 1

            x, y, z = batch
            x = x.to(device)
            y = y.to(device)
            z = z.to(device)

            y_predict = model(x, z)

            loss = model.loss(x, y, z)
            losses += loss.item()
            
            # Save prediction
            for sent_tagids in y_predict:
                Y_predict.append(sent_tagids)
                
            # Save labels 
            for sent_tagids_padded, mask in zip(y, z):
                sent_tagids = torch.masked_select(sent_tagids_padded, mask).tolist()
                Y_true.append(sent_tagids)
    
    acc = get_accuracy_simple(Y_predict, Y_true)

    print("Epoch: {}, Val Loss:{:.4f}, Val Acc:{:.3f}%".format(e, losses/step, acc))
    return model, losses/step, acc

def test(model, iterator, device):
    model.eval()
    Y_true, Y_predict = [], []
    with torch.no_grad():
        for i, batch in enumerate(iterator):
            x, y, z = batch
            x = x.to(device)
            y = y.to(device)
            z = z.to(device)
            
            y_predict = model(x, z)
            # Save prediction
            for sent_tagids in y_predict:
                Y_predict.append(sent_tagids)
                
            # Save labels             
            for sent_tagids_padded, mask in zip(y, z):
                sent_tagids = torch.masked_select(sent_tagids_padded, mask).tolist()
                Y_true.append(sent_tagids)
                
    return Y_predict, Y_true
    
if __name__=="__main__":    
    best_model = None
    _best_val_loss = 1e18
    _best_val_acc = 1e-18

    parser = argparse.ArgumentParser()
    parser.add_argument("--batch_size", type=int, default=Config.batch_size)
    parser.add_argument("--lr", type=float, default=Config.lr)
    parser.add_argument("--n_epochs", type=int, default=Config.n_epochs)
    parser.add_argument("--trainset", type=str, default=Config.trainset)
    parser.add_argument("--validset", type=str, default=Config.validset)
    parser.add_argument("--testset", type=str, default=Config.testset)

    ner = parser.parse_args()
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = BiLSTM_CRF(word2idx, tag2idx, Config.embedding_dim, Config.bilstm_hidden_dim, Config.dropout_rate).cuda()

    print('Initial model Done.')
    train_dataset = NerDataset(ner.trainset)
    eval_dataset = NerDataset(ner.validset)
    test_dataset = NerDataset(ner.testset)
    print('Load Data Done.')

    train_iter = data.DataLoader(dataset=train_dataset,
                                 batch_size=ner.batch_size,
                                 shuffle=True,
                                 num_workers=4,
                                 collate_fn=PadBatch)

    eval_iter = data.DataLoader(dataset=eval_dataset,
                                 batch_size=(ner.batch_size)//2,
                                 shuffle=False,
                                 num_workers=4,
                                 collate_fn=PadBatch)

    test_iter = data.DataLoader(dataset=test_dataset,
                                batch_size=(ner.batch_size)//2,
                                shuffle=False,
                                num_workers=4,
                                collate_fn=PadBatch)

    optimizer = optim.Adam(model.parameters(), lr=ner.lr, weight_decay=0.001)

    print('Start Train...,')
    for epoch in range(1, ner.n_epochs+1):

        train(epoch, model, train_iter, optimizer, device)
        candidate_model, loss, acc = validate(epoch, model, eval_iter, device)

        if loss < _best_val_loss and acc > _best_val_acc:
          best_model = candidate_model
          _best_val_loss = loss
          _best_val_acc = acc

        print("=============================================")
    
    Y_predict, Y_true = test(best_model, test_iter, device)
    Y_predict_flatten = [tagid for sent_tagids in Y_predict for tagid in sent_tagids]
    Y_true_flatten = [tagid for sent_tagids in Y_true for tagid in sent_tagids]
    
    print("**************测试性能**************************")
    print("混淆矩阵（按标签）：")
    print(metrics.confusion_matrix(Y_true_flatten, Y_predict_flatten))
    print()
    
    print("精确率-召回率-F1值（按标签）：")
    y_tag_pred = [idx2tag[i] for i in Y_predict_flatten]
    y_tag_true = [idx2tag[i] for i in Y_true_flatten]    
    print(metrics.classification_report(y_tag_true, y_tag_pred, labels=['O']+Config.VOCAB_tag_entity, digits=3))
    print()
    
    print("精确率-召回率-F1值（按实体）：")
    precision_entity, recall_entity, f1_score_entity, accuracy_entity = get_prf1_entity(Y_predict, Y_true, idx2tag)
    #print(f"精确率:{precision_entity};召回率:{recall_entity};F1值:{f1_score_entity};整体准确率:{accuracy_entity}")
    print(f"精确率:{precision_entity};召回率:{recall_entity};F1值:{f1_score_entity}")
    
    # 保存模型
    torch.save(best_model,"data/model.pth")