import pandas as pd

# -*- coding: utf-8 -*-
'''
@Author:    
@Date:  
@LastEditTime:  
@Description: 
@All Right Reserve
'''
class Config:
    trainset = './data/train.txt'
    validset = './data/dev.txt'
    testset = './data/test.txt'
    vocab_file = './data/vocabulary.txt'
    ######    
    VOCAB_tag_entity = ['B-SENSITIVE', 'I-SENSITIVE'] 
    ######    
    VOCAB_tag = ['<PAD>', 'O'] + VOCAB_tag_entity 
    
    embedding_dim = 150
    batch_size = 64
    lr = 1e-3 #0.001
    n_epochs = 10
    
    bilstm_hidden_dim = 384
    
    dropout_rate = 0.2

with open(Config.vocab_file, mode='r', encoding="utf-8") as f:
    vocabulary = [line.strip()for line in f.readlines()]
word2idx = {word: idx for idx, word in enumerate(vocabulary)}
#print(word2idx["<PAD>"])
idx2word = {idx: word for idx, word in enumerate(vocabulary)}

tag2idx = {tag: idx for idx, tag in enumerate(Config.VOCAB_tag)}
idx2tag = {idx: tag for idx, tag in enumerate(Config.VOCAB_tag)}
#print(tag2idx)

