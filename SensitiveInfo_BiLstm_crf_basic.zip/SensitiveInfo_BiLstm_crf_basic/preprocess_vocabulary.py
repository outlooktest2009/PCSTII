#!/usr/bin/env python
# coding: utf-8

#cd drive/MyDrive/
import re
import os
from config import Config
from typing import List

def get_token_li(fname:str):
    token_li = []
    with open(fname, mode='r', encoding="utf-8") as f:
        for line in f.readlines():
            line = line.strip()
            if (len(line) == 0):
                continue
            else:
                try:
                    token_li.append(line.split()[0])
                except Exception:
                    print("ill formatted line: " + line)
    return token_li

def save_data(fname:str, vocabulary:List[str]):
    with open(fname, mode='w', encoding='utf-8') as f:
        for word in vocabulary:            
            f.write(word + '\n')

if __name__=="__main__":
    vocabulary = []
    vocabulary.extend(['<PAD>','<UNK>'])
    
    for token in get_token_li('./data/train.txt'):
        if token not in vocabulary:
            vocabulary.append(token)
    for token in get_token_li('./data/dev.txt'):
        if token not in vocabulary:
            vocabulary.append(token)
    for token in get_token_li('./data/test.txt'):
        if token not in vocabulary:
            vocabulary.append(token)        
    
    save_data('./data/vocabulary.txt', vocabulary)