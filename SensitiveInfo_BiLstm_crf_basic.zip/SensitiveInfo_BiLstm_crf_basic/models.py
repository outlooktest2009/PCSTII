# -*- coding: utf-8 -*-
'''
@Author:    
@Date:  
@LastEditTime:  
@Description:  
@All Right Reserve
'''

import torch
import torch.nn as nn
from TorchCRF import CRF

class BiLSTM_CRF(nn.Module):

    def __init__(self, word2idx, tag2idx, embedding_dim, hidden_dim, dropout_rate):
        super(BiLSTM_CRF, self).__init__()
        
        self.word_embeds = nn.Embedding(len(word2idx), embedding_dim)
        
        self.lstm_b = nn.LSTM(  input_size=embedding_dim, 
                                hidden_size=hidden_dim//2,
                                num_layers=1, bidirectional=True, batch_first=True)
        self.dropout = nn.Dropout(p=dropout_rate)
        
        self.fc_feature = nn.Linear(hidden_dim, len(tag2idx))
        self.crf = CRF(len(tag2idx))
    
    def _get_hidden_state(self, sentence):        
        token_emb = self.word_embeds(sentence)           
        hidden_state_b, _ = self.lstm_b(token_emb)
        hidden_state_b = self.dropout(hidden_state_b)
        
        return hidden_state_b        
        
    def loss(self, sentence, tags, mask):
        hidden_state = self._get_hidden_state(sentence)        
        emissions = self.fc_feature(hidden_state)
        loss_crf = -self.crf.forward(emissions, tags, mask).mean()
        
        return loss_crf
        
    def forward(self, sentence, mask):
        hidden_state = self._get_hidden_state(sentence)        
        emissions = self.fc_feature(hidden_state)
        decode = self.crf.viterbi_decode(emissions, mask)
        return decode
 
