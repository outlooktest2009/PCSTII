# -*- coding: utf-8 -*-
'''
@Author: 
@Date: 
@LastEditTime: 
@Description:  
@All Right Reserve
'''

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils import data
import os
from config import Config, tag2idx, idx2tag, word2idx, idx2word
from utils import seq2entity

def getEntities(model,sentence,word2idx,idx2tag):    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    words = list(sentence)
    wordidx_li = [word2idx[word] if word in word2idx else word2idx['<UNK>'] for word in words]
    token_tensors = torch.LongTensor([wordidx_li])
    mask = (token_tensors != word2idx['<PAD>'])
    token_tensors = token_tensors.to(device)
    mask = mask.to(device)
    y_predict = model(token_tensors, mask)
    entities_tuple = seq2entity(y_predict[0], idx2tag)
    entities_full =[]
    for e in entities_tuple:
        entity_type, entity_start, entity_end = e[0], e[1], e[2]
        #########
        entities_full.append("".join(words[entity_start:entity_end]) + ":" + entity_type) 
        #########
    print(entities_full)

if __name__=="__main__":
    print("**************实体识别**************************")
    #加载模型
    model=torch.load("./data/model.pth")  
    ########
    #注意测试句子需要去掉其中的空格
    sentence = "国网卫辉市供电公司组织唐庄中心供电所员工主动走访辖区内中州水务有限公司。"
    getEntities(model,sentence,word2idx,idx2tag) 