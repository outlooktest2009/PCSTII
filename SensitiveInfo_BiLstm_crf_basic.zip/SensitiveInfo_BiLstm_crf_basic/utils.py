# -*- coding: utf-8 -*-
'''
@Author: 
@Date: 
@LastEditTime: 
@Description: This file is for implementing Dataset. 
@All Right Reserve
'''

import torch
from torch.utils.data import Dataset
from config import Config, tag2idx, idx2tag, word2idx, idx2word
from typing import List, Dict
import numpy as np

class NerDataset(Dataset):
    ''' Generate our dataset '''
    def __init__(self, f_path):
        self.tokens_li = []
        self.tags_li = []
        
        with open(f_path, mode='r', encoding="utf-8") as f:
            sent_token_li, sent_tag_li = [], []
            for line in f.readlines():
                line = line.strip()
                if (len(line) == 0):
                    if len(sent_token_li) == 0: continue
                    self.tokens_li.append(sent_token_li)
                    self.tags_li.append(sent_tag_li)
                    sent_token_li, sent_tag_li = [], []
                else:
                    sent_token_li.append(line.split()[0])
                    sent_tag_li.append(line.split()[1]) 
                    
    def __getitem__(self, idx):
        tokens, tags = self.tokens_li[idx], self.tags_li[idx]
        assert(len(tokens) == len(tags))
        token_ids = [word2idx[word] if word in word2idx else word2idx['<UNK>'] for word in tokens]
        label_ids = [tag2idx[tag] for tag in tags]
        seqlen = len(label_ids)
        return token_ids, label_ids, seqlen

    def __len__(self):
        return len(self.tokens_li)

def PadBatch(batch):
    maxlen = max([i[2] for i in batch])
    token_tensors = torch.LongTensor([i[0] + [word2idx['<PAD>']] * (maxlen - len(i[0])) for i in batch])
    label_tensors = torch.LongTensor([i[1] + [tag2idx['<PAD>']] * (maxlen - len(i[1])) for i in batch])
    mask = (token_tensors != word2idx['<PAD>'])
    return token_tensors, label_tensors, mask


def get_accuracy_simple(Y_predict:List[List[int]], Y_true:List[List[int]]):
    Y_predict_flatten = [tagid for sent_tagids in Y_predict for tagid in sent_tagids]
    Y_true_flatten = [tagid for sent_tagids in Y_true for tagid in sent_tagids]
    assert(len(Y_predict_flatten) == len(Y_true_flatten))
    comparison = (np.array(Y_predict_flatten) == np.array(Y_true_flatten))
    return comparison.mean() * 100
    
def get_prf1_entity(Y_predict:List[List[int]], Y_true:List[List[int]], idx2tag:Dict[int, str]):
    TP, Total_pred, Total_true = 0, 0, 0
    accs = []
    for sent_tagids_pred, sent_tagids_true in zip(Y_predict, Y_true):
        sent_tagids_pred = sent_tagids_pred[1:-1]
        sent_tagids_true = sent_tagids_true[1:-1]
        
        entities_pred = seq2entity(sent_tagids_pred, idx2tag)
        entities_true = seq2entity(sent_tagids_true, idx2tag)
        #print(f"pred:\t{entities_pred}\ntrue:\t{entities_true}")
        Total_pred += len(entities_pred)
        Total_true += len(entities_true)
        
        TP += len(set(entities_pred)&set(entities_true))
        accs.extend([a==b for (a, b) in zip(entities_pred, entities_true)])
        
    p = 0.0 if TP ==0 else TP / Total_pred
    r = 0.0 if TP ==0 else TP / Total_true
    f1 = 0.0 if TP ==0 else 2 * p * r / (p + r)
    accuracy = 0.0 if np.sum(accs) == 0 else np.mean(accs) 
    return p, r, f1, accuracy

def seq2entity(seq:List[int], idx2tag:Dict[int, str]):
    """Given a sequence of tags, group entities and their position
    Args:
        seq: [4, 4, 0, 0, ...] sequence of labels
        idx2tag: {4: "B-PER", 5: "I-PER", 3:"B-LOC", 0:"O"}
    Returns:
        list of (entity_type, entity_start, entity_end)
    Example:
        seq = [4, 5, 0, 3]
        idx2tag = {4: "B-PER", 5: "I-PER", 3:"B-LOC"}
        result = [("PER", 0, 2), ("LOC", 3, 4)]
    """
    entities = []
    entity_start_li = [i for i, tag_id in enumerate(seq) if idx2tag[tag_id].startswith('B') ]
    if len(entity_start_li) == 0:
        return entities
    for entity_start in entity_start_li:
        tag_id = seq[entity_start]
        tag_name = idx2tag[tag_id]
        tag_class =  tag_name[0]
        tag_type = tag_name[2:]
        entity_type = tag_type
        entity_end = entity_start
        if entity_start == len(seq) - 1:            
            entity_end = len(seq)
            entity = (entity_type, entity_start, entity_end)
            entities.append(entity)
            continue
        for j in range(entity_start + 1, len(seq)):
            tag_id = seq[j]
            tag_name = idx2tag[tag_id]
            tag_class =  tag_name[0]
            
            if tag_class != 'I':                
                entity_end = j
                entity = (entity_type, entity_start, entity_end)
                entities.append(entity)
                break
                
            tag_type = tag_name[2:]
            if tag_class == 'I' and tag_type != entity_type:
                entity_end = j
                entity = (entity_type, entity_start, entity_end)
                entities.append(entity)
                break
        if (j == len(seq) - 1) and (entity_end == entity_start):
            entity_end = len(seq)
            entity = (entity_type, entity_start, entity_end)
            entities.append(entity)
    
    return entities

if __name__=="__main__":
    #seq = [2, 7, 7, 0, 1, 1, 7, 6, 2, 3, 3, 5, 0, 1]
    import random
    seq = [random.randint(0,len(idx2tag)-1) for i in range(14)]
    print(seq)
    tag_seq = [idx2tag[i] for i in seq]
    print(tag_seq)
    entity_start_li = [i for i, tag_id in enumerate(seq) if idx2tag[tag_id].startswith('B') ]
    print(entity_start_li)
    for e in seq2entity(seq, idx2tag):
        print(e)
    